import { NextResponse } from "next/server"
import jwt from "jsonwebtoken"
import { cookies } from "next/headers"

export async function verifyAuth(request: Request) {
  try {
    // Get token from Authorization header
    const authHeader = request.headers.get("authorization")
    let token

    if (authHeader && authHeader.startsWith("Bearer ")) {
      token = authHeader.split(" ")[1]
    } else {
      // Try to get token from cookies
      const cookieStore = cookies()
      token = cookieStore.get("token")?.value
    }

    if (!token) {
      return null
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || "your-secret-key")
    return decoded
  } catch (error) {
    return null
  }
}

export function authMiddleware(handler: Function) {
  return async (request: Request, ...args: any[]) => {
    const user = await verifyAuth(request)

    if (!user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    return handler(request, user, ...args)
  }
}

export function adminMiddleware(handler: Function) {
  return async (request: Request, ...args: any[]) => {
    const user = await verifyAuth(request)

    if (!user || user.role !== "admin") {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    return handler(request, user, ...args)
  }
}
