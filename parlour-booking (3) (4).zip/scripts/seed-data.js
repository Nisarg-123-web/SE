import mongoose from "mongoose"
import bcrypt from "bcryptjs"

// MongoDB connection
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/parlour-booking"

// Define schemas
const UserSchema = new mongoose.Schema(
  {
    name: String,
    email: String,
    phone: String,
    password: String,
    role: {
      type: String,
      enum: ["user", "admin"],
      default: "user",
    },
  },
  { timestamps: true },
)

const ServiceSchema = new mongoose.Schema(
  {
    name: String,
    description: String,
    duration: Number,
    price: Number,
    image: String,
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true },
)

const StylistSchema = new mongoose.Schema(
  {
    name: String,
    specialization: String,
    avatar: String,
    services: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Service",
      },
    ],
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true },
)

// Create models
const User = mongoose.model("User", UserSchema)
const Service = mongoose.model("Service", ServiceSchema)
const Stylist = mongoose.model("Stylist", StylistSchema)

// Seed data
const seedDatabase = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(MONGODB_URI)
    console.log("Connected to MongoDB")

    // Clear existing data
    await User.deleteMany({})
    await Service.deleteMany({})
    await Stylist.deleteMany({})
    console.log("Cleared existing data")

    // Create admin user
    const adminPassword = await bcrypt.hash("admin123", 10)
    const admin = await User.create({
      name: "Admin User",
      email: "admin@example.com",
      phone: "+91 9999999999",
      password: adminPassword,
      role: "admin",
    })
    console.log("Created admin user:", admin.email)

    // Create regular user
    const userPassword = await bcrypt.hash("user123", 10)
    const user = await User.create({
      name: "Priya Sharma",
      email: "user@example.com",
      phone: "+91 9999999999",
      password: userPassword,
      role: "user",
    })
    console.log("Created regular user:", user.email)

    // Create services
    const services = await Service.insertMany([
      {
        name: "Haircut & Styling",
        description: "Professional haircut and styling service",
        duration: 60,
        price: 2500,
        image: "/placeholder.svg",
      },
      {
        name: "Manicure & Pedicure",
        description: "Complete nail care for hands and feet",
        duration: 90,
        price: 3000,
        image: "/placeholder.svg",
      },
      {
        name: "Facial Treatment",
        description: "Customized facial for your skin type",
        duration: 60,
        price: 4000,
        image: "/placeholder.svg",
      },
      {
        name: "Makeup Application",
        description: "Professional makeup for any occasion",
        duration: 45,
        price: 3500,
        image: "/placeholder.svg",
      },
    ])
    console.log("Created services:", services.length)

    // Create stylists with Indian names
    const stylists = await Stylist.insertMany([
      // Haircut & Styling stylists
      {
        name: "Anjali Patel",
        specialization: "Hair Stylist",
        avatar: "/placeholder.svg",
        services: [services[0]._id],
      },
      {
        name: "Rahul Sharma",
        specialization: "Hair Stylist",
        avatar: "/placeholder.svg",
        services: [services[0]._id],
      },
      {
        name: "Deepika Verma",
        specialization: "Hair Stylist",
        avatar: "/placeholder.svg",
        services: [services[0]._id],
      },

      // Manicure & Pedicure stylists
      {
        name: "Neha Singh",
        specialization: "Nail Technician",
        avatar: "/placeholder.svg",
        services: [services[1]._id],
      },
      {
        name: "Pooja Gupta",
        specialization: "Nail Technician",
        avatar: "/placeholder.svg",
        services: [services[1]._id],
      },
      {
        name: "Ritu Malhotra",
        specialization: "Nail Technician",
        avatar: "/placeholder.svg",
        services: [services[1]._id],
      },

      // Facial Treatment stylists
      {
        name: "Vikram Joshi",
        specialization: "Esthetician",
        avatar: "/placeholder.svg",
        services: [services[2]._id],
      },
      {
        name: "Meera Kapoor",
        specialization: "Esthetician",
        avatar: "/placeholder.svg",
        services: [services[2]._id],
      },
      {
        name: "Sanjay Kumar",
        specialization: "Esthetician",
        avatar: "/placeholder.svg",
        services: [services[2]._id],
      },

      // Makeup Application stylists
      {
        name: "Kavita Reddy",
        specialization: "Makeup Artist",
        avatar: "/placeholder.svg",
        services: [services[3]._id],
      },
      {
        name: "Arjun Mehta",
        specialization: "Makeup Artist",
        avatar: "/placeholder.svg",
        services: [services[3]._id],
      },
      {
        name: "Sunita Agarwal",
        specialization: "Makeup Artist",
        avatar: "/placeholder.svg",
        services: [services[3]._id],
      },
    ])
    console.log("Created stylists:", stylists.length)

    console.log("Database seeded successfully!")
    console.log("\nLogin credentials:")
    console.log("Admin: admin@example.com / admin123")
    console.log("User: user@example.com / user123")
  } catch (error) {
    console.error("Error seeding database:", error)
  } finally {
    // Close the connection
    await mongoose.connection.close()
    console.log("MongoDB connection closed")
  }
}

// Run the seed function
seedDatabase()
