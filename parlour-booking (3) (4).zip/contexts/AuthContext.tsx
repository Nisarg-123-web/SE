"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { loginUser, registerUser } from "@/lib/api"
import { setToken, removeToken, isAuthenticated, isAdmin, getUserInfo } from "@/lib/auth"
import { showSuccessAlert, showErrorAlert, showLoadingAlert, closeAlert } from "@/lib/alerts"

interface User {
  id: string
  name: string
  email: string
  role: string
}

interface AuthContextType {
  user: User | null
  loading: boolean
  error: string | null
  isLoggedIn: boolean
  isAdminUser: boolean
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, phone: string, password: string) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in on initial load
    const checkAuth = () => {
      if (isAuthenticated()) {
        const userInfo = getUserInfo()
        if (userInfo) {
          setUser({
            id: userInfo.userId,
            name: "", // We don't have this in the token
            email: userInfo.email,
            role: userInfo.role,
          })
        }
      }
      setLoading(false)
    }

    checkAuth()
  }, [])

  const login = async (email: string, password: string) => {
    setLoading(true)
    setError(null)

    // Show loading alert
    showLoadingAlert("Logging in...")

    try {
      const data = await loginUser({ email, password })
      setToken(data.token)
      setUser({
        id: data.user.id,
        name: data.user.name,
        email: data.user.email,
        role: data.user.role,
      })

      // Close loading alert and show success
      closeAlert()

      // Immediately redirect based on user role without waiting for alert
      const redirectUrl = data.user.role === "admin" ? "/admin/dashboard" : "/dashboard"

      // Use direct window location change for more reliable navigation
      window.location.href = redirectUrl

      // Show success message (will be visible briefly before redirect)
      showSuccessAlert("Login successful!")

      return // Early return to prevent further execution
    } catch (err: any) {
      closeAlert()
      setError(err.message || "Login failed")
      showErrorAlert("Login failed", err.message)
    } finally {
      setLoading(false)
    }
  }

  const register = async (name: string, email: string, phone: string, password: string) => {
    setLoading(true)
    setError(null)

    // Show loading alert
    showLoadingAlert("Creating your account...")

    try {
      await registerUser({ name, email, phone, password })

      // Show success message
      closeAlert()
      await showSuccessAlert("Registration successful!", "Please login with your new account.")

      // Redirect to login page
      window.location.href = "/login"
    } catch (err: any) {
      closeAlert()
      setError(err.message || "Registration failed")
      showErrorAlert("Registration failed", err.message)
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    removeToken()
    setUser(null)
    window.location.href = "/login" // Use window.location for a full page refresh
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        error,
        isLoggedIn: !!user,
        isAdminUser: isAdmin(),
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
