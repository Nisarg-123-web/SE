"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, Check, Clock, IndianRupee } from "lucide-react"
import { useAuth } from "@/contexts/AuthContext"
import { getServices, getStylists, createBooking } from "@/lib/api"
import { showSuccessAlert, showErrorAlert, showLoadingAlert, closeAlert } from "@/lib/alerts"

interface Service {
  _id: string
  name: string
  description: string
  duration: number
  price: number
  image: string
}

interface Stylist {
  _id: string
  name: string
  specialization: string
  avatar: string
  services: string[] | Service[]
}

// Generate time slots from 9 AM to 5 PM
const generateTimeSlots = () => {
  const slots = []
  for (let hour = 9; hour <= 17; hour++) {
    const hourFormatted = hour % 12 === 0 ? 12 : hour % 12
    const period = hour < 12 ? "AM" : "PM"
    slots.push(`${hourFormatted}:00 ${period}`)
  }
  return slots
}

const timeSlots = generateTimeSlots()

export default function BookingPage() {
  const router = useRouter()
  const { isLoggedIn, user } = useAuth()
  const [step, setStep] = useState(1)
  const [booking, setBooking] = useState({
    service: "",
    stylist: "",
    date: new Date(),
    time: "",
    notes: "",
  })
  const [services, setServices] = useState<Service[]>([])
  const [stylists, setStylists] = useState<Stylist[]>([])
  const [filteredStylists, setFilteredStylists] = useState<Stylist[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true)
        // Fetch services
        const servicesData = await getServices("isActive=true")
        setServices(servicesData.services)

        // Fetch all stylists
        const stylistsData = await getStylists("isActive=true")
        setStylists(stylistsData.stylists)
        setFilteredStylists(stylistsData.stylists)

        setIsLoading(false)
      } catch (err: any) {
        setError(err.message || "Failed to load data")
        showErrorAlert("Error", "Failed to load booking options")
        setIsLoading(false)
      }
    }

    fetchData()
  }, [])

  // Filter stylists based on selected service
  useEffect(() => {
    if (booking.service && stylists.length > 0) {
      const filtered = stylists.filter((stylist) => {
        // Check if stylist provides the selected service
        return stylist.services.some((service) =>
          typeof service === "string" ? service === booking.service : service._id === booking.service,
        )
      })
      setFilteredStylists(filtered.length > 0 ? filtered : stylists)
    } else {
      setFilteredStylists(stylists)
    }
  }, [booking.service, stylists])

  const handleServiceSelect = (serviceId: string) => {
    setBooking((prev) => ({ ...prev, service: serviceId }))
    setStep(2)
  }

  const handleStylistSelect = (stylistId: string) => {
    setBooking((prev) => ({ ...prev, stylist: stylistId }))
    setStep(3)
  }

  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      setBooking((prev) => ({ ...prev, date }))
      setStep(4)
    }
  }

  const handleTimeSelect = (time: string) => {
    setBooking((prev) => ({ ...prev, time }))
    setStep(5)
  }

  const handleNotesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setBooking((prev) => ({ ...prev, notes: e.target.value }))
  }

  const handleSubmit = async () => {
    if (!isLoggedIn) {
      showErrorAlert("Authentication Required", "Please login to book an appointment")
      router.push("/login")
      return
    }

    try {
      setIsLoading(true)
      showLoadingAlert("Creating your booking...")

      await createBooking({
        service: booking.service,
        stylist: booking.stylist,
        date: booking.date.toISOString().split("T")[0],
        time: booking.time,
        notes: booking.notes,
      })

      // Show success message
      closeAlert()
      await showSuccessAlert("Booking Successful!", "You will receive a confirmation email shortly.")

      // Redirect to dashboard
      window.location.href = "/dashboard"
    } catch (err: any) {
      closeAlert()
      setError(err.message || "Failed to create booking")
      showErrorAlert("Booking Failed", err.message)
      setIsLoading(false)
    }
  }

  const selectedService = services.find((s) => s._id === booking.service)
  const selectedStylist = stylists.find((s) => s._id === booking.stylist)

  if (isLoading && step === 1) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading booking options...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="text-xl font-bold">
            BeautyBooker
          </Link>
          <div className="flex gap-4">
            {isLoggedIn ? (
              <Link href="/dashboard">
                <Button variant="ghost">Dashboard</Button>
              </Link>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="outline">Login</Button>
                </Link>
                <Link href="/register">
                  <Button>Register</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold mb-8 text-center">Book Your Appointment</h1>

          <div className="mb-8">
            <div className="flex justify-between items-center">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex flex-col items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                      step >= i ? "bg-pink-600 text-white" : "bg-gray-200 text-gray-500"
                    }`}
                  >
                    {step > i ? <Check className="h-5 w-5" /> : i}
                  </div>
                  <div className="text-xs text-center">
                    {i === 1 && "Service"}
                    {i === 2 && "Stylist"}
                    {i === 3 && "Date"}
                    {i === 4 && "Time"}
                    {i === 5 && "Confirm"}
                  </div>
                </div>
              ))}
            </div>
            <div className="relative mt-2">
              <div className="absolute top-0 left-0 right-0 h-1 bg-gray-200">
                <div
                  className="absolute top-0 left-0 h-1 bg-pink-600 transition-all duration-300"
                  style={{ width: `${(step - 1) * 25}%` }}
                ></div>
              </div>
            </div>
          </div>

          {error && <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">{error}</div>}

          {/* Step 1: Select Service */}
          {step === 1 && (
            <div>
              <h2 className="text-xl font-bold mb-4">Select a Service</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {services.map((service) => (
                  <Card
                    key={service._id}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      booking.service === service._id ? "border-pink-500 ring-2 ring-pink-500" : ""
                    }`}
                    onClick={() => handleServiceSelect(service._id)}
                  >
                    <CardHeader className="pb-2">
                      <CardTitle>{service.name}</CardTitle>
                      <CardDescription className="flex items-center">
                        <IndianRupee className="h-3.5 w-3.5 mr-1" />
                        {service.price}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600">{service.description}</p>
                      <div className="flex items-center mt-2 text-sm text-gray-500">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{service.duration} minutes</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Select Stylist */}
          {step === 2 && (
            <div>
              <h2 className="text-xl font-bold mb-4">Select a Stylist</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredStylists.map((stylist) => (
                  <Card
                    key={stylist._id}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      booking.stylist === stylist._id ? "border-pink-500 ring-2 ring-pink-500" : ""
                    }`}
                    onClick={() => handleStylistSelect(stylist._id)}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-full overflow-hidden bg-gray-200">
                          <img
                            src={stylist.avatar || "/placeholder.svg"}
                            alt={stylist.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="font-bold">{stylist.name}</h3>
                          <p className="text-gray-500">{stylist.specialization}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              <div className="mt-6 flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)}>
                  <ArrowLeft className="mr-2 h-4 w-4" /> Back
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Select Date */}
          {step === 3 && (
            <div>
              <h2 className="text-xl font-bold mb-4">Select a Date</h2>
              <Card>
                <CardContent className="p-6">
                  <Calendar
                    mode="single"
                    selected={booking.date}
                    onSelect={handleDateSelect}
                    className="mx-auto"
                    disabled={
                      (date) => date < new Date(new Date().setHours(0, 0, 0, 0)) || date.getDay() === 0 // Disable Sundays
                    }
                  />
                </CardContent>
              </Card>
              <div className="mt-6 flex justify-between">
                <Button variant="outline" onClick={() => setStep(2)}>
                  <ArrowLeft className="mr-2 h-4 w-4" /> Back
                </Button>
              </div>
            </div>
          )}

          {/* Step 4: Select Time */}
          {step === 4 && (
            <div>
              <h2 className="text-xl font-bold mb-4">Select a Time</h2>
              <Card>
                <CardContent className="p-6">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {timeSlots.map((time) => (
                      <Button
                        key={time}
                        variant={booking.time === time ? "default" : "outline"}
                        className={booking.time === time ? "bg-pink-600" : ""}
                        onClick={() => handleTimeSelect(time)}
                      >
                        {time}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
              <div className="mt-6 flex justify-between">
                <Button variant="outline" onClick={() => setStep(3)}>
                  <ArrowLeft className="mr-2 h-4 w-4" /> Back
                </Button>
              </div>
            </div>
          )}

          {/* Step 5: Confirm Booking */}
          {step === 5 && (
            <div>
              <h2 className="text-xl font-bold mb-4">Confirm Your Booking</h2>
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium text-gray-500">Service</h3>
                      <p className="font-bold">{selectedService?.name}</p>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-500">Stylist</h3>
                      <p className="font-bold">{selectedStylist?.name}</p>
                    </div>
                    <div className="flex gap-8">
                      <div>
                        <h3 className="font-medium text-gray-500">Date</h3>
                        <p className="font-bold">
                          {booking.date.toLocaleDateString("en-US", {
                            weekday: "long",
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </p>
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-500">Time</h3>
                        <p className="font-bold">{booking.time}</p>
                      </div>
                    </div>
                    <Separator />
                    <div>
                      <h3 className="font-medium text-gray-500">Price</h3>
                      <p className="font-bold flex items-center">
                        <IndianRupee className="h-4 w-4 mr-1" />
                        {selectedService?.price}
                      </p>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-500">Special Requests (Optional)</h3>
                      <Textarea
                        placeholder="Any special requests or notes for your appointment..."
                        value={booking.notes}
                        onChange={handleNotesChange}
                        className="mt-2"
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={() => setStep(4)}>
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back
                  </Button>
                  <Button onClick={handleSubmit} disabled={isLoading}>
                    {isLoading ? "Processing..." : "Confirm Booking"}
                  </Button>
                </CardFooter>
              </Card>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
