"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock, User, CalendarIcon, Settings, LogOut, IndianRupee } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/AuthContext"
import { getBookings, updateBooking } from "@/lib/api"
import { showSuccessAlert, showErrorAlert, showLoadingAlert, closeAlert, showConfirmAlert } from "@/lib/alerts"
import RescheduleDialog from "@/components/reschedule-dialog"

interface Booking {
  _id: string
  service: {
    _id: string
    name: string
    price: number
    duration: number
  }
  stylist: {
    _id: string
    name: string
    specialization: string
  }
  date: string
  time: string
  notes: string
  status: "pending" | "confirmed" | "cancelled" | "completed"
  createdAt: string
}

export default function DashboardPage() {
  const router = useRouter()
  const { isLoggedIn, user, logout } = useAuth()
  const [upcomingBookings, setUpcomingBookings] = useState<Booking[]>([])
  const [pastBookings, setPastBookings] = useState<Booking[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null)
  const [isRescheduleOpen, setIsRescheduleOpen] = useState(false)

  useEffect(() => {
    // Redirect to login if not authenticated
    if (!isLoggedIn && !isLoading) {
      router.push("/login")
    }
  }, [isLoggedIn, isLoading, router])

  const fetchBookings = async () => {
    if (!isLoggedIn) return

    try {
      setIsLoading(true)
      // Fetch all bookings for the current user
      const data = await getBookings()

      if (!data || !data.bookings || !Array.isArray(data.bookings)) {
        throw new Error("Invalid data format received from API")
      }

      const now = new Date()
      const upcoming: Booking[] = []
      const past: Booking[] = []

      // Sort bookings into upcoming and past
      data.bookings.forEach((booking: Booking) => {
        if (!booking.date || !booking.time) return

        const bookingDate = new Date(`${booking.date}T${booking.time.split(" ")[0]}`)

        if (booking.status === "cancelled") {
          past.push(booking)
        } else if (bookingDate < now || booking.status === "completed") {
          past.push(booking)
        } else {
          upcoming.push(booking)
        }
      })

      // Sort upcoming by date (ascending)
      upcoming.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

      // Sort past by date (descending)
      past.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

      setUpcomingBookings(upcoming)
      setPastBookings(past)
      setIsLoading(false)
    } catch (err: any) {
      setError(err.message || "Failed to load bookings")
      showErrorAlert("Error", "Failed to load your bookings")
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchBookings()
  }, [isLoggedIn])

  const handleCancelBooking = async (bookingId: string) => {
    const result = await showConfirmAlert(
      "Cancel Booking",
      "Are you sure you want to cancel this booking? This action cannot be undone.",
    )

    if (result.isConfirmed) {
      try {
        showLoadingAlert("Cancelling your booking...")
        await updateBooking(bookingId, { status: "cancelled" })
        closeAlert()

        // Update local state
        setUpcomingBookings((prev) => prev.filter((booking) => booking._id !== bookingId))

        // Add to past bookings
        const cancelledBooking = upcomingBookings.find((booking) => booking._id === bookingId)
        if (cancelledBooking) {
          cancelledBooking.status = "cancelled"
          setPastBookings((prev) => [cancelledBooking!, ...prev])
        }

        showSuccessAlert("Booking Cancelled", "Your booking has been cancelled successfully")
      } catch (err: any) {
        closeAlert()
        showErrorAlert("Error", `Failed to cancel booking: ${err.message}`)
      }
    }
  }

  const handleReschedule = (booking: Booking) => {
    setSelectedBooking(booking)
    setIsRescheduleOpen(true)
  }

  const handleBookAgain = (booking: Booking) => {
    router.push("/booking")
  }

  const handleRescheduleComplete = (bookingId: string, newDate: string, newTime: string) => {
    // Update the booking in the UI
    setUpcomingBookings((prev) =>
      prev.map((booking) => (booking._id === bookingId ? { ...booking, date: newDate, time: newTime } : booking)),
    )

    setIsRescheduleOpen(false)
    setSelectedBooking(null)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="text-xl font-bold">
            BeautyBooker
          </Link>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={logout} className="gap-2">
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt={user?.name || "User"} />
              <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Profile</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col items-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src="/placeholder.svg?height=96&width=96" alt={user?.name || "User"} />
                  <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
                </Avatar>
                <h3 className="text-xl font-bold">{user?.name || "User"}</h3>
                <p className="text-gray-500">{user?.email}</p>
                <Separator className="my-4" />
                <nav className="w-full space-y-2">
                  <Button variant="ghost" className="w-full justify-start gap-2">
                    <User className="h-4 w-4" />
                    Edit Profile
                  </Button>
                  <Button variant="ghost" className="w-full justify-start gap-2">
                    <Settings className="h-4 w-4" />
                    Account Settings
                  </Button>
                  <Link href="/booking" className="w-full">
                    <Button className="w-full mt-4">Book New Appointment</Button>
                  </Link>
                </nav>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-3">
            <Tabs defaultValue="upcoming">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold">My Appointments</h2>
                <TabsList>
                  <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                  <TabsTrigger value="past">Past</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="upcoming" className="space-y-4">
                {upcomingBookings.length === 0 ? (
                  <Card>
                    <CardContent className="py-10 text-center">
                      <p className="text-gray-500">You have no upcoming appointments.</p>
                      <Link href="/booking">
                        <Button className="mt-4">Book an Appointment</Button>
                      </Link>
                    </CardContent>
                  </Card>
                ) : (
                  upcomingBookings.map((booking) => (
                    <Card key={booking._id}>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row justify-between">
                          <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4 md:mb-0">
                            <div className="bg-pink-100 p-3 rounded-full">
                              <Calendar className="h-6 w-6 text-pink-600" />
                            </div>
                            <div>
                              <h3 className="text-lg font-bold">{booking.service?.name || "Unknown Service"}</h3>
                              <p className="text-gray-500">with {booking.stylist?.name || "Unknown Stylist"}</p>
                            </div>
                          </div>
                          <div className="flex flex-col md:items-end">
                            <div className="flex items-center gap-2 mb-2">
                              <CalendarIcon className="h-4 w-4 text-gray-500" />
                              <span>{new Date(booking.date).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center gap-2 mb-2">
                              <Clock className="h-4 w-4 text-gray-500" />
                              <span>{booking.time}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <IndianRupee className="h-4 w-4 text-gray-500" />
                              <span>₹{booking.service?.price || 0}</span>
                            </div>
                            <Badge
                              variant={booking.status === "confirmed" ? "default" : "outline"}
                              className={booking.status === "confirmed" ? "bg-green-500 mt-2" : "mt-2"}
                            >
                              {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex justify-end mt-4 gap-2">
                          <Button variant="outline" size="sm" onClick={() => handleReschedule(booking)}>
                            Reschedule
                          </Button>
                          <Button variant="destructive" size="sm" onClick={() => handleCancelBooking(booking._id)}>
                            Cancel
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              <TabsContent value="past" className="space-y-4">
                {pastBookings.length === 0 ? (
                  <Card>
                    <CardContent className="py-10 text-center">
                      <p className="text-gray-500">You have no past appointments.</p>
                    </CardContent>
                  </Card>
                ) : (
                  pastBookings.map((booking) => (
                    <Card key={booking._id}>
                      <CardContent className="p-6">
                        <div className="flex flex-col md:flex-row justify-between">
                          <div className="flex flex-col md:flex-row md:items-center gap-4 mb-4 md:mb-0">
                            <div className="bg-gray-100 p-3 rounded-full">
                              <Calendar className="h-6 w-6 text-gray-600" />
                            </div>
                            <div>
                              <h3 className="text-lg font-bold">{booking.service?.name || "Unknown Service"}</h3>
                              <p className="text-gray-500">with {booking.stylist?.name || "Unknown Stylist"}</p>
                            </div>
                          </div>
                          <div className="flex flex-col md:items-end">
                            <div className="flex items-center gap-2 mb-2">
                              <CalendarIcon className="h-4 w-4 text-gray-500" />
                              <span>{new Date(booking.date).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center gap-2 mb-2">
                              <Clock className="h-4 w-4 text-gray-500" />
                              <span>{booking.time}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <IndianRupee className="h-4 w-4 text-gray-500" />
                              <span>₹{booking.service?.price || 0}</span>
                            </div>
                            <Badge variant="outline" className="mt-2">
                              {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                            </Badge>
                          </div>
                        </div>
                        <div className="flex justify-end mt-4 gap-2">
                          <Button variant="outline" size="sm" onClick={() => handleBookAgain(booking)}>
                            Book Again
                          </Button>
                          {booking.status === "completed" && (
                            <Button variant="secondary" size="sm">
                              Leave Review
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>

      {selectedBooking && (
        <RescheduleDialog
          booking={selectedBooking}
          isOpen={isRescheduleOpen}
          onClose={() => {
            setIsRescheduleOpen(false)
            setSelectedBooking(null)
          }}
          onReschedule={handleRescheduleComplete}
        />
      )}
    </div>
  )
}
