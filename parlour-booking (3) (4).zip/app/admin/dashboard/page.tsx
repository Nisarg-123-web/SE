"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, CalendarIcon, LogOut, Users, Scissors, IndianRupee } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { useRouter } from "next/navigation"
import AdminSidebar from "@/components/admin-sidebar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAuth } from "@/contexts/AuthContext"
import { getBookings, updateBooking } from "@/lib/api"
import { showSuccessAlert, showErrorAlert, showLoadingAlert, closeAlert } from "@/lib/alerts"

interface Booking {
  _id: string
  user: {
    _id: string
    name: string
    email: string
  }
  service: {
    _id: string
    name: string
    price: number
    duration: number
  }
  stylist: {
    _id: string
    name: string
    specialization: string
  }
  date: string
  time: string
  notes: string
  status: "pending" | "confirmed" | "cancelled" | "completed"
  createdAt: string
}

interface Service {
  _id: string
  name: string
  count: number
  percentage: number
}

// Initial stats data
const initialStatsData = {
  totalBookings: 0,
  totalCustomers: 0,
  totalRevenue: 0,
  completedServices: 0,
}

export default function AdminDashboardPage() {
  const router = useRouter()
  const { isLoggedIn, user, isAdminUser, logout } = useAuth()
  const [bookings, setBookings] = useState<Booking[]>([])
  const [statsData, setStatsData] = useState(initialStatsData)
  const [popularServices, setPopularServices] = useState<Service[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")
  const [dataFetched, setDataFetched] = useState(false)

  useEffect(() => {
    // Redirect to login if not authenticated or not admin
    if (!isLoading && (!isLoggedIn || !isAdminUser)) {
      router.push("/login")
    }
  }, [isLoggedIn, isAdminUser, isLoading, router])

  useEffect(() => {
    const fetchData = async () => {
      if (!isLoggedIn || !isAdminUser || dataFetched) return

      try {
        setIsLoading(true)
        // Fetch all bookings with full population
        const data = await getBookings("populate=true")

        if (!data || !data.bookings || !Array.isArray(data.bookings)) {
          throw new Error("Invalid data format received from API")
        }

        // Sort bookings by date (newest first)
        const sortedBookings = [...data.bookings].sort(
          (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime(),
        )

        setBookings(sortedBookings)

        // Calculate stats
        const stats = {
          totalBookings: data.bookings.length,
          totalCustomers: new Set(data.bookings.map((b) => b.user?._id).filter(Boolean)).size,
          totalRevenue: data.bookings
            .filter((b) => b.status === "completed" || b.status === "confirmed")
            .reduce((sum, b) => sum + (b.service?.price || 0), 0),
          completedServices: data.bookings.filter((b) => b.status === "completed").length,
        }

        setStatsData(stats)

        // Calculate popular services
        const serviceMap = new Map<string, { id: string; name: string; count: number }>()

        // Count bookings per service
        data.bookings.forEach((booking: Booking) => {
          if (!booking.service || !booking.service._id || !booking.service.name) return

          const serviceId = booking.service._id
          const serviceName = booking.service.name

          if (serviceMap.has(serviceId)) {
            const service = serviceMap.get(serviceId)!
            service.count += 1
          } else {
            serviceMap.set(serviceId, { id: serviceId, name: serviceName, count: 1 })
          }
        })

        // Convert to array and sort by count
        const servicesArray = Array.from(serviceMap.values())
          .sort((a, b) => b.count - a.count)
          .slice(0, 4)

        // Calculate percentages
        const totalCount = servicesArray.reduce((sum, service) => sum + service.count, 0) || 1 // Avoid division by zero
        const servicesWithPercentage = servicesArray.map((service) => ({
          _id: service.id,
          name: service.name,
          count: service.count,
          percentage: Math.round((service.count / totalCount) * 100),
        }))

        setPopularServices(servicesWithPercentage)
        setDataFetched(true)
        setIsLoading(false)
      } catch (err: any) {
        console.error("Dashboard data fetch error:", err)
        setError(err.message || "Failed to load data")
        showErrorAlert("Error", "Failed to load dashboard data. Please try refreshing the page.")
        setIsLoading(false)
      }
    }

    fetchData()
  }, [isLoggedIn, isAdminUser, dataFetched])

  const handleStatusChange = async (bookingId: string, status: string) => {
    try {
      showLoadingAlert("Updating booking status...")
      await updateBooking(bookingId, { status })
      closeAlert()

      // Update local state
      const updatedBookings = bookings.map((booking) =>
        booking._id === bookingId
          ? { ...booking, status: status as "pending" | "confirmed" | "cancelled" | "completed" }
          : booking,
      )

      setBookings(updatedBookings)

      // Recalculate stats
      const newStats = {
        ...statsData,
        completedServices:
          status === "completed"
            ? statsData.completedServices + 1
            : updatedBookings.filter((b) => b.status === "completed").length,
        totalRevenue: updatedBookings
          .filter((b) => b.status === "completed" || b.status === "confirmed")
          .reduce((sum, b) => sum + (b.service?.price || 0), 0),
      }

      setStatsData(newStats)

      showSuccessAlert("Success", `Booking status updated to ${status}`)
    } catch (err: any) {
      closeAlert()
      showErrorAlert("Error", `Failed to update booking status: ${err.message}`)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-pink-500 mx-auto"></div>
          <p className="mt-4 text-gray-500">Loading admin dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <AdminSidebar />

      <div className="flex-1">
        <header className="bg-white border-b sticky top-0 z-10">
          <div className="px-4 py-4 flex justify-between items-center">
            <h1 className="text-xl font-bold">Admin Dashboard</h1>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={logout} className="gap-2">
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Admin" />
                <AvatarFallback>AD</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        <main className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Total Bookings</p>
                    <p className="text-3xl font-bold">{statsData.totalBookings}</p>
                  </div>
                  <div className="bg-pink-100 p-3 rounded-full">
                    <Calendar className="h-6 w-6 text-pink-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Total Customers</p>
                    <p className="text-3xl font-bold">{statsData.totalCustomers}</p>
                  </div>
                  <div className="bg-blue-100 p-3 rounded-full">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Total Revenue</p>
                    <p className="text-3xl font-bold">₹{statsData.totalRevenue}</p>
                  </div>
                  <div className="bg-green-100 p-3 rounded-full">
                    <IndianRupee className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-500">Completed Services</p>
                    <p className="text-3xl font-bold">{statsData.completedServices}</p>
                  </div>
                  <div className="bg-purple-100 p-3 rounded-full">
                    <Scissors className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Recent Bookings</CardTitle>
              <CardDescription>Manage your recent appointment bookings</CardDescription>
            </CardHeader>
            <CardContent>
              {bookings.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Customer</TableHead>
                      <TableHead>Service</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>Stylist</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bookings.slice(0, 10).map((booking) => (
                      <TableRow key={booking._id}>
                        <TableCell className="font-medium">{booking.user?.name || "Unknown"}</TableCell>
                        <TableCell>{booking.service?.name || "Unknown"}</TableCell>
                        <TableCell>{new Date(booking.date).toLocaleDateString()}</TableCell>
                        <TableCell>{booking.time}</TableCell>
                        <TableCell>{booking.stylist?.name || "Unknown"}</TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              booking.status === "confirmed"
                                ? "bg-green-100 text-green-800 border-green-200"
                                : booking.status === "pending"
                                  ? "bg-yellow-100 text-yellow-800 border-yellow-200"
                                  : booking.status === "completed"
                                    ? "bg-blue-100 text-blue-800 border-blue-200"
                                    : "bg-red-100 text-red-800 border-red-200"
                            }
                          >
                            {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Select
                            defaultValue={booking.status}
                            onValueChange={(value) => handleStatusChange(booking._id, value)}
                          >
                            <SelectTrigger className="w-[130px]">
                              <SelectValue placeholder="Change status" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="confirmed">Confirm</SelectItem>
                              <SelectItem value="pending">Pending</SelectItem>
                              <SelectItem value="cancelled">Cancel</SelectItem>
                              <SelectItem value="completed">Complete</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">No bookings found. New bookings will appear here.</p>
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Previous</Button>
              <Button variant="outline">Next</Button>
            </CardFooter>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Upcoming Appointments</CardTitle>
                <CardDescription>Today and tomorrow's schedule</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {bookings
                    .filter(
                      (b) => b.status !== "cancelled" && b.status !== "completed" && new Date(b.date) >= new Date(),
                    )
                    .slice(0, 3)
                    .map((booking) => (
                      <div
                        key={booking._id}
                        className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0"
                      >
                        <div className="flex items-center gap-4">
                          <div className="bg-gray-100 p-2 rounded-full">
                            <CalendarIcon className="h-5 w-5 text-gray-600" />
                          </div>
                          <div>
                            <p className="font-medium">{booking.service?.name || "Unknown Service"}</p>
                            <p className="text-sm text-gray-500">{booking.user?.name || "Unknown Customer"}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{booking.time}</p>
                          <p className="text-sm text-gray-500">{new Date(booking.date).toLocaleDateString()}</p>
                        </div>
                      </div>
                    ))}
                  {bookings.filter(
                    (b) => b.status !== "cancelled" && b.status !== "completed" && new Date(b.date) >= new Date(),
                  ).length === 0 && (
                    <div className="text-center py-4">
                      <p className="text-gray-500">No upcoming appointments.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Popular Services</CardTitle>
                <CardDescription>Most booked services this month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {popularServices.length > 0 ? (
                    popularServices.map((service: Service) => (
                      <div key={service._id}>
                        <div className="flex justify-between items-center">
                          <p className="font-medium">{service.name}</p>
                          <p className="font-medium">{service.count} bookings</p>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
                          <div className="bg-pink-600 h-2.5 rounded-full" style={{ width: `${service.percentage}%` }} />
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 text-center py-4">No booking data available yet.</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
