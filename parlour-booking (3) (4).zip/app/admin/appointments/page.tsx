"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/AuthContext"
import AdminSidebar from "@/components/admin-sidebar"

export default function AppointmentsPage() {
  const router = useRouter()
  const { isLoggedIn, isAdminUser } = useAuth()

  useEffect(() => {
    if (!isLoggedIn || !isAdminUser) {
      router.push("/login")
    }
  }, [isLoggedIn, isAdminUser, router])

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <AdminSidebar />
      <div className="flex-1 p-8">
        <h1 className="text-2xl font-bold mb-6">Appointments Management</h1>
        <div className="bg-white p-6 rounded-lg shadow">
          <p className="text-gray-500">
            This page is under development. Check back soon for appointment management features.
          </p>
        </div>
      </div>
    </div>
  )
}
