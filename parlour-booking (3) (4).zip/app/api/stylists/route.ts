import { NextResponse } from "next/server"
import connectToDatabase from "@/lib/mongodb"
import Stylist from "@/models/Stylist"
import { verifyAuth } from "@/middleware/auth"

// GET all stylists
export async function GET(request: Request) {
  try {
    await connectToDatabase()

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const isActive = searchParams.get("isActive")
    const serviceId = searchParams.get("service")

    const query: any = {}

    // Filter by active status if provided
    if (isActive !== null) {
      query.isActive = isActive === "true"
    }

    // Filter by service if provided
    if (serviceId) {
      query.services = serviceId
    }

    const stylists = await Stylist.find(query).populate("services", "name").sort({ name: 1 })

    return NextResponse.json({ stylists })
  } catch (error) {
    console.error("Get stylists error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// POST create a new stylist (admin only)
export async function POST(request: Request) {
  try {
    const user = await verifyAuth(request)
    if (!user || user.role !== "admin") {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const { name, specialization, avatar, services } = await request.json()

    // Validate input
    if (!name || !specialization) {
      return NextResponse.json({ message: "Name and specialization are required" }, { status: 400 })
    }

    // Create new stylist
    const stylist = await Stylist.create({
      name,
      specialization,
      avatar: avatar || "/placeholder.svg",
      services: services || [],
    })

    // Return success response
    return NextResponse.json({
      message: "Stylist created successfully",
      stylist,
    })
  } catch (error) {
    console.error("Create stylist error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
