import { NextResponse } from "next/server"
import connectToDatabase from "@/lib/mongodb"
import Stylist from "@/models/Stylist"
import { verifyAuth } from "@/middleware/auth"

// GET a specific stylist
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase()

    const stylistId = params.id
    const stylist = await Stylist.findById(stylistId).populate("services", "name price duration")

    if (!stylist) {
      return NextResponse.json({ message: "Stylist not found" }, { status: 404 })
    }

    return NextResponse.json({ stylist })
  } catch (error) {
    console.error("Get stylist error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// PUT update a stylist (admin only)
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await verifyAuth(request)
    if (!user || user.role !== "admin") {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const stylistId = params.id
    const stylist = await Stylist.findById(stylistId)

    if (!stylist) {
      return NextResponse.json({ message: "Stylist not found" }, { status: 404 })
    }

    const { name, specialization, avatar, services, isActive } = await request.json()

    // Update stylist fields if provided
    if (name) stylist.name = name
    if (specialization) stylist.specialization = specialization
    if (avatar) stylist.avatar = avatar
    if (services) stylist.services = services
    if (isActive !== undefined) stylist.isActive = isActive

    // Save updated stylist
    await stylist.save()

    return NextResponse.json({
      message: "Stylist updated successfully",
      stylist,
    })
  } catch (error) {
    console.error("Update stylist error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// DELETE a stylist (admin only)
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await verifyAuth(request)
    if (!user || user.role !== "admin") {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const stylistId = params.id
    const stylist = await Stylist.findById(stylistId)

    if (!stylist) {
      return NextResponse.json({ message: "Stylist not found" }, { status: 404 })
    }

    // Delete stylist
    await Stylist.findByIdAndDelete(stylistId)

    return NextResponse.json({
      message: "Stylist deleted successfully",
    })
  } catch (error) {
    console.error("Delete stylist error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
