import { NextResponse } from "next/server"
import connectToDatabase from "@/lib/mongodb"
import Service from "@/models/Service"
import { verifyAuth } from "@/middleware/auth"

// GET all services
export async function GET(request: Request) {
  try {
    await connectToDatabase()

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const isActive = searchParams.get("isActive")

    const query: any = {}

    // Filter by active status if provided
    if (isActive !== null) {
      query.isActive = isActive === "true"
    }

    const services = await Service.find(query).sort({ name: 1 })

    return NextResponse.json({ services })
  } catch (error) {
    console.error("Get services error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// POST create a new service (admin only)
export async function POST(request: Request) {
  try {
    const user = await verifyAuth(request)
    if (!user || user.role !== "admin") {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const { name, description, duration, price, image } = await request.json()

    // Validate input
    if (!name || !description || !duration || !price) {
      return NextResponse.json({ message: "Name, description, duration, and price are required" }, { status: 400 })
    }

    // Create new service
    const service = await Service.create({
      name,
      description,
      duration,
      price,
      image: image || "/placeholder.svg",
    })

    // Return success response
    return NextResponse.json({
      message: "Service created successfully",
      service,
    })
  } catch (error) {
    console.error("Create service error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
