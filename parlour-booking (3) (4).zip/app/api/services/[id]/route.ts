import { NextResponse } from "next/server"
import connectToDatabase from "@/lib/mongodb"
import Service from "@/models/Service"
import { verifyAuth } from "@/middleware/auth"

// GET a specific service
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    await connectToDatabase()

    const serviceId = params.id
    const service = await Service.findById(serviceId)

    if (!service) {
      return NextResponse.json({ message: "Service not found" }, { status: 404 })
    }

    return NextResponse.json({ service })
  } catch (error) {
    console.error("Get service error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// PUT update a service (admin only)
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await verifyAuth(request)
    if (!user || user.role !== "admin") {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const serviceId = params.id
    const service = await Service.findById(serviceId)

    if (!service) {
      return NextResponse.json({ message: "Service not found" }, { status: 404 })
    }

    const { name, description, duration, price, image, isActive } = await request.json()

    // Update service fields if provided
    if (name) service.name = name
    if (description) service.description = description
    if (duration) service.duration = duration
    if (price) service.price = price
    if (image) service.image = image
    if (isActive !== undefined) service.isActive = isActive

    // Save updated service
    await service.save()

    return NextResponse.json({
      message: "Service updated successfully",
      service,
    })
  } catch (error) {
    console.error("Update service error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// DELETE a service (admin only)
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await verifyAuth(request)
    if (!user || user.role !== "admin") {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const serviceId = params.id
    const service = await Service.findById(serviceId)

    if (!service) {
      return NextResponse.json({ message: "Service not found" }, { status: 404 })
    }

    // Delete service
    await Service.findByIdAndDelete(serviceId)

    return NextResponse.json({
      message: "Service deleted successfully",
    })
  } catch (error) {
    console.error("Delete service error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
