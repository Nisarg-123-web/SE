import { NextResponse } from "next/server"
import connectToDatabase from "@/lib/mongodb"
import Booking from "@/models/Booking"
import { verifyAuth } from "@/middleware/auth"

// GET all bookings (admin) or user's bookings
export async function GET(request: Request) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")
    const status = searchParams.get("status")
    const populate = searchParams.get("populate") === "true"

    const query: any = {}

    // Filter by user ID if not admin
    if (user.role !== "admin" || userId) {
      query.user = userId || user.userId
    }

    // Filter by status if provided
    if (status) {
      query.status = status
    }

    // Find bookings and populate related data
    const bookingsQuery = Booking.find(query)
      .populate("user", "name email")
      .populate("service", "name price duration")
      .populate("stylist", "name specialization")
      .sort({ date: 1, time: 1 })

    // Execute the query
    const bookings = await bookingsQuery

    return NextResponse.json({ bookings })
  } catch (error) {
    console.error("Get bookings error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// POST create a new booking
export async function POST(request: Request) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const { service, stylist, date, time, notes } = await request.json()

    // Validate input
    if (!service || !stylist || !date || !time) {
      return NextResponse.json({ message: "Service, stylist, date, and time are required" }, { status: 400 })
    }

    // Create new booking
    const booking = await Booking.create({
      user: user.userId,
      service,
      stylist,
      date: new Date(date),
      time,
      notes: notes || "",
      status: "pending",
    })

    // Populate booking data
    await booking.populate("service", "name price duration")
    await booking.populate("stylist", "name specialization")

    // Return success response
    return NextResponse.json({
      message: "Booking created successfully",
      booking,
    })
  } catch (error) {
    console.error("Create booking error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
