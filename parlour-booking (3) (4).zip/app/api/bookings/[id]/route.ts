import { NextResponse } from "next/server"
import connectToDatabase from "@/lib/mongodb"
import Booking from "@/models/Booking"
import { verifyAuth } from "@/middleware/auth"

// GET a specific booking
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const bookingId = params.id

    // Find booking and populate related data
    const booking = await Booking.findById(bookingId)
      .populate("user", "name email")
      .populate("service", "name price duration")
      .populate("stylist", "name specialization")

    if (!booking) {
      return NextResponse.json({ message: "Booking not found" }, { status: 404 })
    }

    // Check if user is authorized to view this booking
    if (user.role !== "admin" && booking.user._id.toString() !== user.userId) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 403 })
    }

    return NextResponse.json({ booking })
  } catch (error) {
    console.error("Get booking error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// PUT update a booking
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const bookingId = params.id
    const booking = await Booking.findById(bookingId)

    if (!booking) {
      return NextResponse.json({ message: "Booking not found" }, { status: 404 })
    }

    // Check if user is authorized to update this booking
    if (user.role !== "admin" && booking.user.toString() !== user.userId) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 403 })
    }

    const { service, stylist, date, time, notes, status } = await request.json()

    // Update booking fields if provided
    if (service) booking.service = service
    if (stylist) booking.stylist = stylist
    if (date) booking.date = new Date(date)
    if (time) booking.time = time
    if (notes !== undefined) booking.notes = notes
    if (status) booking.status = status

    // Save updated booking
    await booking.save()

    // Populate booking data
    await booking.populate("user", "name email")
    await booking.populate("service", "name price duration")
    await booking.populate("stylist", "name specialization")

    return NextResponse.json({
      message: "Booking updated successfully",
      booking,
    })
  } catch (error) {
    console.error("Update booking error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}

// DELETE a booking
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const user = await verifyAuth(request)
    if (!user) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 })
    }

    await connectToDatabase()

    const bookingId = params.id
    const booking = await Booking.findById(bookingId)

    if (!booking) {
      return NextResponse.json({ message: "Booking not found" }, { status: 404 })
    }

    // Check if user is authorized to delete this booking
    if (user.role !== "admin" && booking.user.toString() !== user.userId) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 403 })
    }

    // Delete booking
    await Booking.findByIdAndDelete(bookingId)

    return NextResponse.json({
      message: "Booking deleted successfully",
    })
  } catch (error) {
    console.error("Delete booking error:", error)
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
