import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function HeroSection() {
  return (
    <section className="relative bg-gradient-to-r from-pink-50 to-purple-50 py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">Book Your Beauty Appointment With Ease</h1>
          <p className="text-xl text-gray-600 mb-8">
            Experience the best beauty services in town. Book your appointment online and get pampered by our
            professional stylists.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/booking">
              <Button size="lg" className="px-8">
                Book Now
              </Button>
            </Link>
            <Link href="#services">
              <Button size="lg" variant="outline" className="px-8">
                Our Services
              </Button>
            </Link>
          </div>
        </div>
      </div>
      <div className="absolute right-0 bottom-0 w-1/3 h-2/3 bg-pink-200 opacity-20 rounded-tl-full hidden lg:block"></div>
    </section>
  )
}
