import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Scissors, Sparkles, Droplet, Brush } from "lucide-react"
import Link from "next/link"

const services = [
  {
    id: 1,
    title: "Haircut & Styling",
    description: "Professional haircuts and styling services for all hair types and preferences.",
    price: "From ₹2500",
    icon: Scissors,
  },
  {
    id: 2,
    title: "Manicure & Pedicure",
    description: "Relaxing and rejuvenating nail care services to keep your hands and feet looking their best.",
    price: "From ₹3000",
    icon: Sparkles,
  },
  {
    id: 3,
    title: "Facial Treatments",
    description: "Customized facial treatments to address your specific skin concerns and needs.",
    price: "From ₹4000",
    icon: Droplet,
  },
  {
    id: 4,
    title: "Makeup Services",
    description: "Professional makeup application for special occasions or everyday glamour.",
    price: "From ₹3500",
    icon: Brush,
  },
]

export default function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Our Services</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We offer a wide range of beauty services to help you look and feel your best. Our professional team is
            dedicated to providing exceptional service.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service) => (
            <Card key={service.id} className="transition-all hover:shadow-lg">
              <CardHeader>
                <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center mb-4">
                  <service.icon className="w-6 h-6 text-pink-600" />
                </div>
                <CardTitle>{service.title}</CardTitle>
                <CardDescription>{service.price}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">{service.description}</p>
              </CardContent>
              <CardFooter>
                <Link href="/booking" className="w-full">
                  <Button variant="outline" className="w-full">
                    Book Now
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
