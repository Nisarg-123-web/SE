"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { updateBooking } from "@/lib/api"
import { showSuccessAlert, showErrorAlert, showLoadingAlert, closeAlert } from "@/lib/alerts"
import { IndianRupee } from "lucide-react"

interface Booking {
  _id: string
  service: {
    _id: string
    name: string
    price?: number
  }
  stylist: {
    _id: string
    name: string
  }
  date: string
  time: string
}

interface RescheduleDialogProps {
  booking: Booking
  isOpen: boolean
  onClose: () => void
  onReschedule: (bookingId: string, newDate: string, newTime: string) => void
}

// Generate time slots from 9 AM to 5 PM
const generateTimeSlots = () => {
  const slots = []
  for (let hour = 9; hour <= 17; hour++) {
    const hourFormatted = hour % 12 === 0 ? 12 : hour % 12
    const period = hour < 12 ? "AM" : "PM"
    slots.push(`${hourFormatted}:00 ${period}`)
  }
  return slots
}

const timeSlots = generateTimeSlots()

export default function RescheduleDialog({ booking, isOpen, onClose, onReschedule }: RescheduleDialogProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date(booking.date))
  const [selectedTime, setSelectedTime] = useState(booking.time)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleReschedule = async () => {
    if (!selectedDate || !selectedTime) {
      showErrorAlert("Error", "Please select both date and time")
      return
    }

    try {
      setIsSubmitting(true)
      showLoadingAlert("Rescheduling your appointment...")

      // Format date for API
      const formattedDate = selectedDate.toISOString().split("T")[0]

      // Update booking via API
      await updateBooking(booking._id, {
        date: formattedDate,
        time: selectedTime,
      })

      closeAlert()
      showSuccessAlert("Success", "Your appointment has been rescheduled")

      // Notify parent component
      onReschedule(booking._id, formattedDate, selectedTime)
    } catch (error: any) {
      closeAlert()
      showErrorAlert("Error", error.message || "Failed to reschedule appointment")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Reschedule Appointment</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div>
              <h3 className="mb-2 font-medium">Service</h3>
              <p>
                {booking.service?.name || "Unknown Service"} with {booking.stylist?.name || "Unknown Stylist"}
              </p>
              {booking.service?.price && (
                <p className="flex items-center mt-1 text-gray-600">
                  <IndianRupee className="h-3.5 w-3.5 mr-1" />
                  {booking.service.price}
                </p>
              )}
            </div>
            <div>
              <h3 className="mb-2 font-medium">Select New Date</h3>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                disabled={
                  (date) => date < new Date(new Date().setHours(0, 0, 0, 0)) || date.getDay() === 0 // Disable Sundays
                }
                className="rounded-md border"
              />
            </div>
            <div>
              <h3 className="mb-2 font-medium">Select New Time</h3>
              <div className="grid grid-cols-3 gap-2">
                {timeSlots.map((time) => (
                  <Button
                    key={time}
                    type="button"
                    variant={selectedTime === time ? "default" : "outline"}
                    className={selectedTime === time ? "bg-pink-600" : ""}
                    onClick={() => setSelectedTime(time)}
                  >
                    {time}
                  </Button>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button onClick={handleReschedule} disabled={isSubmitting}>
              {isSubmitting ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
