import mongoose from "mongoose"

const StylistSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Please provide a stylist name"],
      maxlength: [60, "Name cannot be more than 60 characters"],
    },
    specialization: {
      type: String,
      required: [true, "Please provide a specialization"],
    },
    avatar: {
      type: String,
      default: "/placeholder.svg",
    },
    services: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Service",
      },
    ],
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true },
)

export default mongoose.models.Stylist || mongoose.model("Stylist", StylistSchema)
