import mongoose from "mongoose"

const ServiceSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Please provide a service name"],
      maxlength: [100, "Name cannot be more than 100 characters"],
    },
    description: {
      type: String,
      required: [true, "Please provide a description"],
    },
    duration: {
      type: Number,
      required: [true, "Please provide service duration in minutes"],
    },
    price: {
      type: Number,
      required: [true, "Please provide service price"],
    },
    image: {
      type: String,
      default: "/placeholder.svg",
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  { timestamps: true },
)

export default mongoose.models.Service || mongoose.model("Service", ServiceSchema)
