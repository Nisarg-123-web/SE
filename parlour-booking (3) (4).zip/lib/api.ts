import { getToken } from "./auth"

const API_URL = process.env.NEXT_PUBLIC_API_URL || "/api"

interface ApiOptions {
  method?: string
  body?: any
  headers?: Record<string, string>
  cache?: RequestCache
  next?: { revalidate?: number }
}

export async function fetchApi(endpoint: string, options: ApiOptions = {}) {
  const { method = "GET", body, headers = {}, cache = "no-store", next = { revalidate: 0 } } = options

  const token = getToken()
  if (token) {
    headers.Authorization = `Bearer ${token}`
  }

  headers["Content-Type"] = "application/json"

  const config: RequestInit = {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
    cache,
    next,
  }

  try {
    const response = await fetch(`${API_URL}${endpoint}`, config)

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}))
      throw new Error(errorData.message || `API error: ${response.status} ${response.statusText}`)
    }

    const data = await response.json()
    return data
  } catch (error) {
    console.error(`API error for ${endpoint}:`, error)
    throw error
  }
}

// Auth API calls
export const loginUser = (credentials: { email: string; password: string }) => {
  return fetchApi("/auth/login", {
    method: "POST",
    body: credentials,
  })
}

export const registerUser = (userData: { name: string; email: string; phone: string; password: string }) => {
  return fetchApi("/auth/register", {
    method: "POST",
    body: userData,
  })
}

// Bookings API calls
export const getBookings = (params = "") => {
  return fetchApi(`/bookings${params ? `?${params}` : ""}`, {
    cache: "no-store", // Ensure we always get fresh data
    next: { revalidate: 0 },
  })
}

export const getBooking = (id: string) => {
  return fetchApi(`/bookings/${id}`, {
    cache: "no-store",
    next: { revalidate: 0 },
  })
}

export const createBooking = (bookingData: any) => {
  return fetchApi("/bookings", {
    method: "POST",
    body: bookingData,
  })
}

export const updateBooking = (id: string, bookingData: any) => {
  return fetchApi(`/bookings/${id}`, {
    method: "PUT",
    body: bookingData,
  })
}

export const deleteBooking = (id: string) => {
  return fetchApi(`/bookings/${id}`, {
    method: "DELETE",
  })
}

// Services API calls
export const getServices = (params = "") => {
  return fetchApi(`/services${params ? `?${params}` : ""}`, {
    cache: "no-store",
    next: { revalidate: 0 },
  })
}

export const getService = (id: string) => {
  return fetchApi(`/services/${id}`, {
    cache: "no-store",
    next: { revalidate: 0 },
  })
}

export const createService = (serviceData: any) => {
  return fetchApi("/services", {
    method: "POST",
    body: serviceData,
  })
}

export const updateService = (id: string, serviceData: any) => {
  return fetchApi(`/services/${id}`, {
    method: "PUT",
    body: serviceData,
  })
}

export const deleteService = (id: string) => {
  return fetchApi(`/services/${id}`, {
    method: "DELETE",
  })
}

// Stylists API calls
export const getStylists = (params = "") => {
  return fetchApi(`/stylists${params ? `?${params}` : ""}`, {
    cache: "no-store",
    next: { revalidate: 0 },
  })
}

export const getStylist = (id: string) => {
  return fetchApi(`/stylists/${id}`, {
    cache: "no-store",
    next: { revalidate: 0 },
  })
}

export const createStylist = (stylistData: any) => {
  return fetchApi("/stylists", {
    method: "POST",
    body: stylistData,
  })
}

export const updateStylist = (id: string, stylistData: any) => {
  return fetchApi(`/stylists/${id}`, {
    method: "PUT",
    body: stylistData,
  })
}

export const deleteStylist = (id: string) => {
  return fetchApi(`/stylists/${id}`, {
    method: "DELETE",
  })
}
