import { jwtDecode } from "jwt-decode"

interface DecodedToken {
  userId: string
  email: string
  role: string
  exp: number
}

export const getToken = () => {
  if (typeof window !== "undefined") {
    return localStorage.getItem("token")
  }
  return null
}

export const setToken = (token: string) => {
  if (typeof window !== "undefined") {
    localStorage.setItem("token", token)
  }
}

export const removeToken = () => {
  if (typeof window !== "undefined") {
    localStorage.removeItem("token")
  }
}

export const isAuthenticated = () => {
  const token = getToken()
  if (!token) return false

  try {
    const decoded = jwtDecode<DecodedToken>(token)
    const currentTime = Date.now() / 1000

    // Check if token is expired
    if (decoded.exp < currentTime) {
      removeToken()
      return false
    }

    return true
  } catch (error) {
    removeToken()
    return false
  }
}

export const isAdmin = () => {
  const token = getToken()
  if (!token) return false

  try {
    const decoded = jwtDecode<DecodedToken>(token)
    return decoded.role === "admin"
  } catch (error) {
    return false
  }
}

export const getUserId = () => {
  const token = getToken()
  if (!token) return null

  try {
    const decoded = jwtDecode<DecodedToken>(token)
    return decoded.userId
  } catch (error) {
    return null
  }
}

export const getUserInfo = () => {
  const token = getToken()
  if (!token) return null

  try {
    return jwtDecode<DecodedToken>(token)
  } catch (error) {
    return null
  }
}
