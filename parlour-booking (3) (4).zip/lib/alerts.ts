import Swal from "sweetalert2"

export const showSuccessAlert = (title: string, message?: string) => {
  return Swal.fire({
    icon: "success",
    title,
    text: message,
    timer: 2000,
    showConfirmButton: false,
  })
}

export const showErrorAlert = (title: string, message?: string) => {
  return Swal.fire({
    icon: "error",
    title,
    text: message,
    confirmButtonColor: "#ec4899",
  })
}

export const showConfirmAlert = (title: string, message: string) => {
  return Swal.fire({
    icon: "warning",
    title,
    text: message,
    showCancelButton: true,
    confirmButtonColor: "#ec4899",
    cancelButtonColor: "#6b7280",
    confirmButtonText: "Yes",
    cancelButtonText: "No",
  })
}

export const showLoadingAlert = (title: string) => {
  return Swal.fire({
    title,
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading()
    },
  })
}

export const closeAlert = () => {
  Swal.close()
}
